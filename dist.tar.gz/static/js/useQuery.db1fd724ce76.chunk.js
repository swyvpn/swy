import{o as e}from"./vendor.dee56adfed90.chunk.js";const s=()=>{const{search:r}=e();return new URLSearchParams(r)};export{s as u};
