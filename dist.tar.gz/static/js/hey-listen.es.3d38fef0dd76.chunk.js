var e=function(){},n=function(){};const t=Object.freeze(Object.defineProperty({__proto__:null,invariant:n,warning:e},Symbol.toStringTag,{value:"Module"}));export{t as h,n as i,e as w};
